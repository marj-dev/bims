// Request form: shows service details, builds extra fields, previews proof, and a review dialog before submit.
document.addEventListener('DOMContentLoaded', function () {
  var form = document.getElementById('reqForm'); if (!form) return;
  var services = JSON.parse(form.getAttribute('data-services') || '{}');
  var sel = document.getElementById('service_id'), box = document.getElementById('serviceBox');
  var extra = document.getElementById('extra'), pay = form.querySelector('[data-pay]'), payInfo = document.getElementById('payInfo');
  var proof = document.getElementById('proof'), prev = document.getElementById('proofPreview');
  var dlg = document.getElementById('reviewDlg'), body = document.getElementById('reviewBody');
  function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
  function money(n) { return 'PHP ' + Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }

  function render() {
    var s = services[sel.value]; extra.innerHTML = '';
    if (!s) { box.hidden = true; pay.hidden = true; return; }
    box.hidden = false;
    box.innerHTML = '<strong>' + esc(s.name) + '</strong><p>' + esc(s.description) + '</p><p><strong>Requirements:</strong><br>' +
      esc(s.requirements).replace(/\n/g, '<br>') + '</p><p><strong>Official fee:</strong> ' + (s.pay ? money(s.fee) : 'No payment required') +
      (s.days ? '<br><strong>Processing time:</strong> about ' + s.days + ' working day(s)' : '') + '</p>';
    (s.extra || []).forEach(function (f) {
      var wrap = document.createElement('div'); wrap.className = 'field';
      var id = 'x_' + f.key, input = f.type === 'textarea' ? document.createElement('textarea') : document.createElement('input');
      if (f.type !== 'textarea') input.type = f.type === 'number' ? 'number' : (f.type === 'date' ? 'date' : 'text');
      input.id = id; input.name = 'extra[' + f.key + ']'; if (f.required) input.required = true;
      var lab = document.createElement('label'); lab.htmlFor = id; lab.textContent = f.label + (f.required ? ' *' : '');
      wrap.appendChild(lab); wrap.appendChild(input); extra.appendChild(wrap);
    });
    pay.hidden = !s.pay;
    if (s.pay) payInfo.innerHTML = 'Amount due: <strong>' + money(s.fee) + '</strong>.<br>' + esc(s.instructions || 'Payment instructions will be provided by the barangay.').replace(/\n/g, '<br>') +
      (s.methods ? '<br>Accepted: ' + esc(s.methods) : '');
  }
  sel.addEventListener('change', render); render();

  if (proof) proof.addEventListener('change', function () {
    var f = proof.files[0]; prev.hidden = true;
    if (!f) return;
    if (f.size > 3 * 1024 * 1024) { alert('That file is larger than 3 MB.'); proof.value = ''; return; }
    if (f.type.indexOf('image/') === 0) { prev.src = URL.createObjectURL(f); prev.hidden = false; }
  });

  document.getElementById('reviewBtn').addEventListener('click', function () {
    var s = services[sel.value];
    if (!s) { alert('Choose a document first.'); sel.focus(); return; }
    var purpose = document.getElementById('purpose');
    if (!purpose.value.trim()) { alert('Please state the purpose of your request.'); purpose.focus(); return; }
    var rows = '<dl class="kv"><dt>Document</dt><dd>' + esc(s.name) + '</dd><dt>Purpose</dt><dd>' + esc(purpose.value) + '</dd>';
    var missing = false;
    extra.querySelectorAll('input,textarea').forEach(function (i) {
      if (i.required && !i.value.trim()) missing = true;
      rows += '<dt>' + esc(i.previousSibling.textContent) + '</dt><dd>' + esc(i.value) + '</dd>';
    });
    if (missing) { alert('Please complete the required fields.'); return; }
    rows += '<dt>Fee</dt><dd>' + (s.pay ? money(s.fee) : 'No payment required') + '</dd>';
    if (s.pay) rows += '<dt>Proof attached</dt><dd>' + (proof && proof.files[0] ? esc(proof.files[0].name) : 'Not yet (you can upload later)') + '</dd>';
    body.innerHTML = rows + '</dl>';
    dlg.showModal();
  });
  document.getElementById('cancelBtn').addEventListener('click', function () { dlg.close(); });
});
