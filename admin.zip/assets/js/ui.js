// Design-preview behavior only (no server): menu toggle, confirm, toasts, filters, mark-as-read, form interception.
(function () {
  var toastEl;
  function toast(msg) {
    if (!toastEl) { toastEl = document.createElement('div'); toastEl.className = 'toast'; toastEl.setAttribute('role', 'status'); document.body.appendChild(toastEl); }
    toastEl.textContent = msg; toastEl.classList.add('show');
    clearTimeout(toastEl._t); toastEl._t = setTimeout(function () { toastEl.classList.remove('show'); }, 2200);
  }
  var toggle = document.querySelector('.nav-toggle'), nav = document.getElementById('site-nav');
  if (toggle && nav) toggle.addEventListener('click', function () {
    var open = nav.classList.toggle('open'); toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  document.addEventListener('click', function (e) {
    var c = e.target.closest('[data-confirm]');
    if (c && !window.confirm(c.getAttribute('data-confirm'))) { e.preventDefault(); e.stopPropagation(); return; }
    var d = e.target.closest('[data-demo]');
    if (d) { e.preventDefault(); toast(d.getAttribute('data-demo') || 'Design preview: this action is not connected.'); }
    var r = e.target.closest('[data-markread]');
    if (r) { var n = r.closest('.notif'); if (n) n.classList.remove('unread'); r.remove(); }
    if (e.target.closest('[data-markall]')) {
      document.querySelectorAll('.notif.unread').forEach(function (x) { x.classList.remove('unread'); });
      document.querySelectorAll('[data-markread]').forEach(function (x) { x.remove(); });
    }
  });
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.classList.contains('logout-form')) return;          // plain link back to the login page
    e.preventDefault();
    var dlg = document.getElementById('reviewDlg'); if (dlg && dlg.open) dlg.close();
    if (f.hasAttribute('data-redirect')) { window.location.href = f.getAttribute('data-redirect'); return; }
    toast('Design preview: the form was not submitted.');
  });
  document.querySelectorAll('[data-filter]').forEach(function (inp) {
    inp.addEventListener('input', function () {
      var v = inp.value.trim().toLowerCase();
      document.querySelectorAll(inp.getAttribute('data-filter') + ' tbody tr').forEach(function (tr) {
        tr.hidden = v && tr.textContent.toLowerCase().indexOf(v) === -1;
      });
    });
  });
})();
